package com.capg.sprint.service;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import javax.security.auth.login.AccountLockedException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.sprint.entity.BankDetails;
import com.capg.sprint.repository.IBankDetailsRepository;

@Service //Makes the class as service provider class
public class BankDetailsService implements IBankDetailsService{
@Autowired
IBankDetailsRepository bankDetailsRepository;

@Override
public boolean addBankAccount(BankDetails bankDetailsObj) {
	boolean addFlag=false;
	try {
			bankDetailsRepository.save(bankDetailsObj);
			addFlag=true;
	}
	catch(Exception e) 
		{
			e.printStackTrace();
		}
	return addFlag;
}

@Override
public List<BankDetails> viewBankAccount(BigInteger accountNumber) {
	List<BankDetails> accountDetails=new ArrayList<BankDetails>();
	try {
			accountDetails=bankDetailsRepository.getAccountDetails(accountNumber);
		}
	catch(Exception e) 
		{
			e.printStackTrace();
		}
	return accountDetails;
}

@Override
public List<BankDetails> viewAllBankAccounts() {
	List<BankDetails> allAccountDetails=new ArrayList<BankDetails>();
	try {
			allAccountDetails=bankDetailsRepository.findAll();
		}
	catch(Exception e) 
		{
			e.printStackTrace();//chill karo ho jayega
		}
	return allAccountDetails;
} 

@Override
public boolean deleteBankAccount(BigInteger accountNumber) {
	boolean deleteFlag=false;
	try {
			bankDetailsRepository.deleteAccountByNo(accountNumber);
		}
	catch(Exception e)
		{
			e.printStackTrace();
			deleteFlag=true;
		}
	return deleteFlag;
}


}
