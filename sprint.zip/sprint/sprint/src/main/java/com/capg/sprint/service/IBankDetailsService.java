package com.capg.sprint.service;

import java.math.BigInteger;
import java.util.List;

import com.capg.sprint.entity.BankDetails;

public interface IBankDetailsService {
	
public boolean addBankAccount(BankDetails bankDetailsObj);
public List<BankDetails> viewBankAccount(BigInteger accountNumber);
public List<BankDetails> viewAllBankAccounts();
public boolean deleteBankAccount(BigInteger accountNumber);

}