package com.capg.sprint.Exception;

public class BankException extends RuntimeException{

}
