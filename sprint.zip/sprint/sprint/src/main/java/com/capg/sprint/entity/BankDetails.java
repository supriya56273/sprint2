package com.capg.sprint.entity;

import java.math.BigInteger;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="bank_details")
public class BankDetails {
@Id
private BigInteger accountNo;
private String holderName;
private String ifscCode;
private String bankName;

public BigInteger getAccountNo() {
	return accountNo;
}
public void setAccountNo(BigInteger accountNo) {
	this.accountNo = accountNo;
}
public String getHolderName() {
	return holderName;
}
public void setHolderName(String holderName) {
	this.holderName = holderName;
}
public String getIfscCode() {
	return ifscCode;
}
public void setIfscCode(String ifscCode) {
	this.ifscCode = ifscCode;
}
public String getBankName() {
	return bankName;
}
public void setBankName(String bankName) {
	this.bankName = bankName;
}

public BankDetails(BigInteger accountNo, String holderName, String ifscCode, String bankName) {
	super();
	this.accountNo = accountNo;
	this.holderName = holderName;
	this.ifscCode = ifscCode;
	this.bankName = bankName;
}
public BankDetails() {}
}
